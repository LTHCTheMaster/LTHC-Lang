package lthclang.var.number;

public class DVarInstSet 
{
	private float dVar = 0;
	
	public DVarInstSet() {
		// TODO Auto-generated constructor stub
	}
	
	public void setDVar(float var)
	{
		dVar = var;
	}
	
	public float getDVar()
	{
		return dVar;
	}

	public String getDVarStr() {
		return Float.toString(getDVar());
	}
}
