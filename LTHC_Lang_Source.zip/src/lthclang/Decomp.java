package lthclang;

import lthclang.basicinst.PrintInstSet;
import lthclang.var.number.AVarInstSet;
import lthclang.var.number.BVarInstSet;
import lthclang.var.number.CVarInstSet;
import lthclang.var.number.DVarInstSet;

public class Decomp
{
	private Reader prgm = new Reader();
	private PrintInstSet print = new PrintInstSet();
	private String inst;
	private AVarInstSet variableA = new AVarInstSet();
	private BVarInstSet variableB = new BVarInstSet();
	private CVarInstSet variableC = new CVarInstSet();
	private DVarInstSet variableD = new DVarInstSet();
	
	public void executerMethod()
	{
		for(String str : prgm.getPrgm())
		{
			this.inst = str.split(" ")[0];
			//Print Instruction
			if(this.inst.equalsIgnoreCase("print"))
			{
				String inst2 = "";
				for(int i = 1; i < str.split(" ").length; i++)
				{
					inst2 += str.split(" ")[i] + " ";
				}
				print.print(inst2);
			}
			//Set AVar Instruction
			if(this.inst.equalsIgnoreCase("ato"))
			{
				variableA.setAVar(Float.parseFloat(str.split(" ")[1]));
			}
			//Print AVar Instruction
			if(this.inst.equalsIgnoreCase("printavar"))
			{
				print.print(variableA.getAVarStr());
			}
			//Set BVar Instruction
			if(this.inst.equalsIgnoreCase("bto"))
			{
				variableB.setBVar(Float.parseFloat(str.split(" ")[1]));
			}
			//Print BVar Instruction
			if(this.inst.equalsIgnoreCase("printbvar"))
			{
				print.print(variableB.getBVarStr());
			}
			//Set CVar Instruction
			if(this.inst.equalsIgnoreCase("cto"))
			{
				variableC.setCVar(Float.parseFloat(str.split(" ")[1]));
			}
			//Print CVar Instruction
			if(this.inst.equalsIgnoreCase("printcvar"))
			{
				print.print(variableC.getCVarStr());
			}
			//Set DVar Instruction
			if(this.inst.equalsIgnoreCase("dto"))
			{
				variableD.setDVar(Float.parseFloat(str.split(" ")[1]));
			}
			//Print DVar Instruction
			if(this.inst.equalsIgnoreCase("printdvar"))
			{
				print.print(variableD.getDVarStr());
			}
		}
	}
}
