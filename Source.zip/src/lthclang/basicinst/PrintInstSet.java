package lthclang.basicinst;

import javax.swing.JOptionPane;

public class PrintInstSet 
{
	public PrintInstSet() {
		// TODO Auto-generated constructor stub
	}
	
	public void print(String str)
	{
		JOptionPane.showMessageDialog(null, str);
	}

}
