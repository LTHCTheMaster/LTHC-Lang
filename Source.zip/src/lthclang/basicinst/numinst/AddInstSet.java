package lthclang.basicinst.numinst;

public class AddInstSet 
{
	public AddInstSet() {
		// TODO Auto-generated constructor stub
	}
	
	public float addNumVar(float var1, float var2)
	{
		return var1 + var2;
	}
}
