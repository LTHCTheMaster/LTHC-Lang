package lthclang.var.str;

public class StrTroisVarInstSet 
{
	private String strVar = "";
	
	public StrTroisVarInstSet() {
		// TODO Auto-generated constructor stub
	}
	
	public void setStrVar(String str)
	{
		this.strVar = str;
	}
	
	public String getStrVar()
	{
		return this.strVar;
	}
}
