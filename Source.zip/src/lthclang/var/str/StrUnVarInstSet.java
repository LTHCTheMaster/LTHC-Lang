package lthclang.var.str;

public class StrUnVarInstSet 
{
	private String strVar = "";
	
	public StrUnVarInstSet() {
		// TODO Auto-generated constructor stub
	}
	
	public void setStrVar(String str)
	{
		this.strVar = str;
	}
	
	public String getStrVar()
	{
		return this.strVar;
	}
}
