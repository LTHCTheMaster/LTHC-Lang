package lthclang;

public class Main {

	public static void main(String[] args) {
		Decomp decomp = new Decomp();
		decomp.executerMethod();
	}

}
